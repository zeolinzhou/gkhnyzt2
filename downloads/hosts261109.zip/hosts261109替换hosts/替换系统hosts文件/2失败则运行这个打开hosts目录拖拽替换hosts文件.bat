@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

rem  获取管理员权限
echo 正在请求管理员权限...
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo 没有管理员权限，正在以管理员身份重新启动...
    powershell start -verb runas '%0'
    exit /b
)
cd /d "%~dp0"
rem 打开hosts目录
:o
echo.
start C:\Windows\System32\drivers\etc
echo. & pause